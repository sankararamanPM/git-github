﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PlanDigitization_web.Models;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PlanDigitization_web.Controllers
{
    public class FirstPassYieldController : Controller
    {
        public ActionResult FirstPassYieldHistoricDashboard()
        {
            return View();
        }
        public ActionResult HourlyTrackerLive()
        {
            return View();
        }
        public ActionResult FirstPassYieldLiveDashboard()
        {
            return View();
        }
        
    }
}