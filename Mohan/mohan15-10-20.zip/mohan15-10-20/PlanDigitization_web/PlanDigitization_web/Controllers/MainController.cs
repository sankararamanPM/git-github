﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Web.Security;

namespace PlanDigitization_web.Controllers
{
    public class MainController : Controller
    {
        string Baseurl = @System.Configuration.ConfigurationManager.AppSettings["url"];
        //View Login Page
        public ActionResult Login()
        {
            //FormsAuthentication.SignOut();
            //Session.Abandon();

            //// clear authentication cookie
            //HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            //cookie1.Expires = DateTime.Now.AddYears(-1);
            //Response.Cookies.Add(cookie1);

            //// clear session cookie (not necessary for your current problem but i would recommend you do it anyway)
            //SessionStateSection sessionStateSection = (SessionStateSection)WebConfigurationManager.GetSection("system.web/sessionState");
            //HttpCookie cookie2 = new HttpCookie(sessionStateSection.CookieName, "");
            //cookie2.Expires = DateTime.Now.AddYears(-1);
            //Response.Cookies.Add(cookie2);
            return View();
        }
        public ActionResult otplogin()
        {
            return View();
        }
        //View Dashboard
        public ActionResult Dashboard()
        {
            return View();
        }
        public ActionResult Settings_err()
        {
            return View();
        }

        //View Forgot Password
        public ActionResult Forgot()
        {
            return View();
        }

        //View Change Password
        public ActionResult ChangePassword()
        {
            return View();
        }

        public ActionResult Logout()
        {
            Response.Cookies["UserID"].Value = "";
            Session["CompanyCode"] = "";
            Session["UserID"] = "";
            Session["UserName"] = "";
            Session["User_Function"] = "";
            Session["IsSuperAdmin"] = "";
            Session["Role"] = "";
            Session["PlantCode"] = "";
            Session["CustomerLogo"] = null;
            Session["Email"] = "";
            return RedirectToAction("Login","Main");
        }

        [HttpPost]
        public ActionResult Checklogin(Models.Loginmodel lo)
        {
            using (var client = new HttpClient())
            {
                lo.lastlogin = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PostAsJsonAsync<Models.Loginmodel>("api/UserSettings/Check_login", lo).Result;
                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content.ReadAsStringAsync().Result;

                    Models.Loginmodelres loginmodelres = new JavaScriptSerializer().Deserialize<Models.Loginmodelres>(res);
                    TempData["message"] = loginmodelres.loginstatus.ToString();
                    List<Models.login> DasList = new List<Models.login>();
                    if (loginmodelres.loginstatus.ToString() == "Login Successfull...!")
                    {
                        HttpResponseMessage loginres = client.PostAsJsonAsync<Models.Loginmodel>("api/UserSettings/Get_Login_details", lo).Result;
                        if (loginres.IsSuccessStatusCode)
                        {
                            var login_data = loginres.Content.ReadAsStringAsync().Result;
                            DasList = JsonConvert.DeserializeObject<List<Models.login>>(login_data);
                            Response.Cookies["UserID"].Value = DasList[0].UserID;
                            //Response.Cookies["UserID"].HttpOnly = true;
                            //Response.Cookies["UserID"].Secure = Convert.ToBoolean(ConfigurationManager.AppSettings["SecureCookie"]);
                            Session["CompanyCode"] = DasList[0].CompanyCode;
                            Session["UserID"] = DasList[0].UserID;
                            Session["UserName"] = DasList[0].UserName;
                            Session["User_Function"] = DasList[0].User_Function;
                            Session["IsSuperAdmin"] = DasList[0].IsSuperAdmin;
                            Session["Role"] = DasList[0].RoleName;
                            Session["PlantCode"] = DasList[0].PlantCode;
                            Session["CustomerLogo"] = null;
                            if (DasList[0].Logo != null)
                            {
                                if (DasList[0].Logo.ToString() != "")
                                {
                                    Session["CustomerLogo"] = DasList[0].Logo;
                                }
                                else
                                {
                                    Session["CustomerLogo"] = null;
                                }
                            }
                            else
                            {
                                Session["CustomerLogo"] = null;
                            }
                            Session["Email"] = DasList[0].Email;
                            Session["lastlogin"] = loginmodelres.lastlogindate.ToString();
                            Session["IsAdmin"] = DasList[0].IsAdmin;
                        }
                    }
                    return View("Login");
                }
                return View("Login");
            }
        }

        public ActionResult Line_details()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ChangePwd(Models.Changepassword C)
        {
            C.Input1 = Session["Email"].ToString();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.PostAsJsonAsync<Models.Changepassword>("api/UserSettings/Changepassword", C).Result;
                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content.ReadAsStringAsync().Result;
                    var msg = JsonConvert.DeserializeObject(res);
                    TempData["message"] = msg;
                }
                return View("ChangePassword");
            }
        }

        public ActionResult Unauth_page()
        {
            return View();
        }
    }
}