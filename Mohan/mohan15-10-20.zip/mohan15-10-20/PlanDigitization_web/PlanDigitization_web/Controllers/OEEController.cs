﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PlanDigitization_web.Controllers
{
    public class OEEController : Controller
    {
        public ActionResult OEELiveDashboard()
        {
            return View();
        }

        public ActionResult OEEHistoricDashboard()
        {
            return View();
        }
    }
}