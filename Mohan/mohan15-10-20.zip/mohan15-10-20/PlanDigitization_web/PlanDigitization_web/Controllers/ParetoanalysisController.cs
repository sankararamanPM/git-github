﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PlanDigitization_web.Controllers
{
    public class ParetoanalysisController : Controller
    {
        public ActionResult Paretoanalysis()
        {
            return View();
        }

        public ActionResult MTTR()
        {
            return View();
        }

        public ActionResult MTBF()
        {
            return View();
        }

        public ActionResult MOA()
        {
            return View();
        }
        public ActionResult AndonLive()
        {
            return View();
        }
    }
}