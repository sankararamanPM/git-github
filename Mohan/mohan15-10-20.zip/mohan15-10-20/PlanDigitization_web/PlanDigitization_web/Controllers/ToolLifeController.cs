﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PlanDigitization_web.Models;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PlanDigitization_web.Controllers
{
    public class ToolLifeController : Controller
    {
        public ActionResult ToolLifeLiveDashboard()
        {
            return View();
        }
        public ActionResult ToolLifeHistoricDashboard()
        {
            return View();
        }
        public ActionResult PreventiveMaintanenceDashboard()
        {
            return View();
        }
    }
}